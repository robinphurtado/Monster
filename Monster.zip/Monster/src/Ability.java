public interface Ability {

    //this is a tagging interface.  This is all we know about it as of Hw 01

}
