public interface Attack extends Ability {

    //this is an interface that is organized under the Ability interface
    //That is all we know as of HW01

    public abstract Integer attack(Monster target);


}
